#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []


def fail(message):
    errors.append(message)


def mask_luau(source):
    output = list(source)
    index = 0
    length = len(source)
    while index < length:
        if source.startswith('--', index):
            match = re.match(r'--\[(=*)\[', source[index:])
            if match:
                closing = ']' + match.group(1) + ']'
                end = source.find(closing, index + match.end())
                end = length if end < 0 else end + len(closing)
            else:
                end = source.find('\n', index)
                end = length if end < 0 else end
            for cursor in range(index, end):
                if output[cursor] != '\n':
                    output[cursor] = ' '
            index = end
            continue
        if source[index] in ('"', "'", '`'):
            quote = source[index]
            end = index + 1
            while end < length:
                if source[end] == '\\':
                    end += 2
                    continue
                if source[end] == quote:
                    end += 1
                    break
                end += 1
            for cursor in range(index, min(end, length)):
                if output[cursor] != '\n':
                    output[cursor] = ' '
            index = end
            continue
        match = re.match(r'\[(=*)\[', source[index:])
        if match:
            closing = ']' + match.group(1) + ']'
            end = source.find(closing, index + match.end())
            end = length if end < 0 else end + len(closing)
            for cursor in range(index, end):
                if output[cursor] != '\n':
                    output[cursor] = ' '
            index = end
            continue
        index += 1
    return ''.join(output)


def validate_syntax(path):
    source = path.read_text()
    masked = mask_luau(source)
    delimiters = {'(': ')', '{': '}', '[': ']'}
    closing = {value: key for key, value in delimiters.items()}
    stack = []
    line = 1
    for character in masked:
        if character == '\n':
            line += 1
            continue
        if character in delimiters:
            stack.append((character, line))
        elif character in closing:
            if not stack or stack[-1][0] != closing[character]:
                fail(f'{path.name}:{line}: unmatched {character}')
                return
            stack.pop()
    if stack:
        token, token_line = stack[-1]
        fail(f'{path.name}:{token_line}: unclosed {token}')

    blocks = []
    pending_loop_do = 0
    for match in re.finditer(r'[A-Za-z_][A-Za-z0-9_]*', masked):
        token = match.group(0)
        token_line = masked.count('\n', 0, match.start()) + 1
        if token == 'function':
            blocks.append((token, token_line))
        elif token == 'if':
            blocks.append((token, token_line))
        elif token in ('for', 'while'):
            blocks.append((token, token_line))
            pending_loop_do += 1
        elif token == 'repeat':
            blocks.append((token, token_line))
        elif token == 'do':
            if pending_loop_do:
                pending_loop_do -= 1
            else:
                blocks.append((token, token_line))
        elif token == 'until':
            if not blocks or blocks[-1][0] != 'repeat':
                fail(f'{path.name}:{token_line}: unmatched until')
                return
            blocks.pop()
        elif token == 'end':
            if not blocks or blocks[-1][0] == 'repeat':
                fail(f'{path.name}:{token_line}: unmatched end')
                return
            blocks.pop()
    if blocks:
        token, token_line = blocks[-1]
        fail(f'{path.name}:{token_line}: unclosed {token} block')


luau_files = sorted(ROOT.glob('*.luau'))
if not luau_files:
    fail('no Luau files found')
for path in luau_files:
    validate_syntax(path)
    for line_number, line in enumerate(path.read_text().splitlines(), 1):
        if line.startswith(' '):
            fail(f'{path.name}:{line_number}: spaces used for indentation')
            break

for directory in ROOT.rglob('*'):
    if directory.is_dir() and directory.name == 'chunks':
        fail(f'obsolete chunks directory included: {directory.relative_to(ROOT)}')

version = (ROOT / 'VERSION').read_text().strip()
main_source = (ROOT / 'main.luau').read_text()
loader_source = (ROOT / 'loader.luau').read_text()
readme_source = (ROOT / 'README.md').read_text()

if f'Version = "{version}"' not in main_source:
    fail('VERSION does not match main.luau')
if version not in (ROOT / 'RELEASE.md').read_text():
    fail('VERSION does not match RELEASE.md')
if len(main_source) < 150000:
    fail('main.luau appears truncated')
if not main_source.rstrip().endswith('return X64UI'):
    fail('main.luau does not return X64UI')

required_once = [
    'function X64UI:CreateWindow(options)',
    'function X64UI:CreateDebuggerWindow(options)',
    'function Window:AddCPUView(options)',
    'function Window:AddGraphView(name, options)',
    'function Window:AddTableView(name, options)',
    'function Window:AddTextView(name, options)',
    'function Window:SetActionHandler(name, callback)',
    'function Window:InvokeAction(name, ...)',
    'function Window:SetDebugState(state, detail)',
]
for marker in required_once:
    count = main_source.count(marker)
    if count != 1:
        fail(f'expected one {marker!r}, found {count}')

for marker in ('CreateDebuggerWindow', 'AddCPUView', 'request', 'REQUIRED_MARKERS'):
    if marker not in loader_source:
        fail(f'loader is missing {marker}')

masked_main = mask_luau(main_source)
for legacy_service in ('UserInputService', 'RunService', 'TweenService', 'GuiService', 'HttpService'):
    if re.search(rf'\b{legacy_service}\b', masked_main):
        fail(f'legacy service identifier remains: {legacy_service}')

if 'chunks/' in readme_source or 'src/chunks' in main_source or 'src/chunks' in loader_source:
    fail('obsolete chunk dependency remains')

if errors:
    for error in errors:
        print('ERROR:', error)
    sys.exit(1)

print(f'OK: {len(luau_files)} Luau files, {len(main_source.splitlines())} main lines, version {version}')
